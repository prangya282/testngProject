package testlogic;

/**
 * @author 609684083
 * test
 *
 */
public class Details extends WebPage {

	public Details() {
		super();
	}
	
	
	public static boolean isOpened;
	
	public static boolean isRaiseEscPopup;
	
	public static boolean isAllOKForSaasOrder = true;
	
	public static String faultRefNo;
	
	
	
	
	
	
	
}
