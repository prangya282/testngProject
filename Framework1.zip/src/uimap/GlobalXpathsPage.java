package uimap;
import frameworklibrary.*;

/**
 * @author 609684083
 *
 */
public class GlobalXpathsPage {


	public static final Locator btnSubmit = new Locator("xpath","//input[@id='submit' or @value='submit']");
	
	




}
