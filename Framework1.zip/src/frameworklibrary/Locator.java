/**
 * 
 */
package frameworklibrary;

/**
 * @author 611593052---> Subhodeep Ganguly
 *
 */
public class Locator {

	public String key;
	public String value;

	public Locator(String key, String value) {
		this.key = key;
		this.value = value;
	}

}
